import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => (
  <nav className="bg-primary text-white p-4">
    <div className="container mx-auto flex justify-between">
      <h1 className="text-xl font-bold">GKL Business Solutions</h1>
      <div className="space-x-4">
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/services">Services</Link>
        <Link to="/projects">Projects</Link>
        <Link to="/contact">Contact</Link>
      </div>
    </div>
  </nav>
);
export default Navbar;