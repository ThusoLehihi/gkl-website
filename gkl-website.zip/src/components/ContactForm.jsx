import React, { useState } from 'react';
import emailjs from 'emailjs-com';

const ContactForm = () => {
  const [message, setMessage] = useState("");

  const sendEmail = (e) => {
    e.preventDefault();
    emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', e.target, 'YOUR_USER_ID')
      .then(() => setMessage("Message sent successfully!"))
      .catch(() => setMessage("Failed to send message."));
  };

  return (
    <form onSubmit={sendEmail} className="space-y-4 max-w-md mx-auto">
      <input type="text" name="name" placeholder="Your Name" required className="w-full p-2 border" />
      <input type="email" name="email" placeholder="Your Email" required className="w-full p-2 border" />
      <textarea name="message" placeholder="Your Message" required className="w-full p-2 border" />
      <button type="submit" className="bg-primary text-white px-4 py-2">Send</button>
      {message && <p className="text-sm mt-2">{message}</p>}
    </form>
  );
};

export default ContactForm;