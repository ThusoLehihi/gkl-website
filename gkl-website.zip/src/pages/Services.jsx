import React from 'react';
const Services = () => <div className='p-6'>Our Services</div>;
export default Services;