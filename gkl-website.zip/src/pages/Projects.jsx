import React from 'react';
const Projects = () => <div className='p-6'>Our Projects</div>;
export default Projects;