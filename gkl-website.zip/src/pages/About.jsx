import React from 'react';
const About = () => <div className='p-6'>About Us</div>;
export default About;