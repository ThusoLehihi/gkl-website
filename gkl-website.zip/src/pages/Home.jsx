import React from 'react';

const Home = () => (
  <div className="p-6 text-center">
    <h2 className="text-4xl font-heading font-bold mb-4">Welcome to GKL Business Solutions</h2>
    <p className="text-lg text-gray-700">We deliver smart and scalable software solutions.</p>
  </div>
);
export default Home;