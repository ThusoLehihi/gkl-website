import React from 'react';

const Blog = () => (
  <div className="p-6">
    <h2 className="text-3xl font-bold mb-4">Blog</h2>
    <p className="text-gray-700">Coming soon: Insights, updates, and stories from GKL Business Solutions.</p>
  </div>
);
export default Blog;